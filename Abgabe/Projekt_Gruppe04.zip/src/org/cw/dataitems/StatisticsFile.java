package org.cw.dataitems;

public class StatisticsFile {

}
